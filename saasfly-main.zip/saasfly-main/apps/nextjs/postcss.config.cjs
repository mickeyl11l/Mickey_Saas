module.exports = require("@saasfly/tailwind-config/postcss");
